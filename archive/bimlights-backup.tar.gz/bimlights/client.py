# -*- coding: utf-8 -*
import time
import serial
import urllib
import time
import json

ser = serial.Serial(
    port = '/dev/ttyACM0',
    baudrate = 9600,
)

praeambel = "\x00\x00\x00"
praeambel += "\x23\x54\x26\x66"
praeambel += "\x00\x00\x50"

def get():
    url = "http://doebi.at:5000"
    try:
        r = urllib.urlopen(url)
        data = r.read()
        print data
    except:
	data = ""
        print("Error: Server not responding")

    return data.replace('0', '\x00').replace('1', '\xC8')

def show(data):
    ser.write(praeambel)
    ser.write(data)

def lightsOut():
    show("\x00"*150)

while True:
    dump = get()
    #lightsOut()
    show(dump)
    time.sleep(15)

ser.close()
